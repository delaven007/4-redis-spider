from scrapy import cmdline

cmdline.execute('scrapy crawl tuniu'.split())