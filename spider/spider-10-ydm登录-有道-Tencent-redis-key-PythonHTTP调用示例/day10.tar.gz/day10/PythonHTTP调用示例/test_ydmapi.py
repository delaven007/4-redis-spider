from ydmapi import *

result = get_result('yzm4.jpg')

# UNXN
print(result)

















